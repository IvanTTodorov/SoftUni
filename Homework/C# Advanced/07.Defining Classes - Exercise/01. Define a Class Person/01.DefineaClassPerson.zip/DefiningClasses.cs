﻿using System;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;
namespace DefiningClasses
{

    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Name = "Maria";
            person.Age = 24; 
        }
    }
}