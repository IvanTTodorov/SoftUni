﻿using System;

namespace AuthorProblem
{
    [Author("Ivan")]
    public class StartUp
    {
        [Author("George")]

        static void Main(string[] args)
        {
            Tracker tracker = new Tracker();
            tracker.PrintMethodsByAuthor("George");

        }

        [Author("George")]
        public void Play()
        {
            Console.WriteLine("Playing");
        }

        [Author("George")]
        public void Eat()
        {
            Console.WriteLine("Eating");
        }
    }
}
