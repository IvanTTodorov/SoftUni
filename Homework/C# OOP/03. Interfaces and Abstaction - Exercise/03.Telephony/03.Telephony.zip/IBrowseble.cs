﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IBrowseble
    {
        string Browse(string url);
    }
}
