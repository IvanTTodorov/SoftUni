﻿using System;

namespace Telephony
{
    internal class Program
    {
        static void Main(string[] args)
        {

            SmartPhone smartPhone = new SmartPhone();
            smartPhone.Run();
        }
    }
}

