﻿using System;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;
namespace Zoo
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}